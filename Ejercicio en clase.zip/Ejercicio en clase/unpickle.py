from data_persistence import unpickle_object, pickle_object

s_2 = unpickle_object('./Ejercicio en clase/saved_stack')
print('El top es', s_2.top)